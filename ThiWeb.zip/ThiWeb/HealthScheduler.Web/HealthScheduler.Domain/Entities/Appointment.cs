﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HealthScheduler.Domain.Enums;



namespace HealthScheduler.Domain.Entities
{
    public class Appointment
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string FullName { get; set; } = null!;

        [Required]
        [Phone]
        public string Phone { get; set; } = null!;

        [DataType(DataType.Date)]
        public DateTime DateOfBirth { get; set; }

        [Required]
        public string Gender { get; set; } = null!;

        public string? Reason { get; set; }

        // Trạng thái lịch hẹn (Pending, Confirmed, Canceled...)
        public AppointmentStatus Status { get; set; } = AppointmentStatus.Pending;

        // Liên kết đến TimeSlot
        public int TimeSlotId { get; set; }
        public TimeSlot? TimeSlot { get; set; }

        // Liên kết đến người dùng (nếu đăng nhập)
        public string? UserId { get; set; }
        //public ApplicationUser? User { get; set; }
    }
}
