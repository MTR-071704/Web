﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthScheduler.Domain.Entities
{
    public class Service
    {
        public int Id { get; set; }

        public string Name { get; set; } = null!; // Ví dụ: "Tim mạch", "Da liễu"

        public string? Description { get; set; } // Mô tả chuyên khoa (nếu cần)

        // Navigation: Danh sách khung giờ liên quan (1 chuyên khoa có nhiều TimeSlot)
        public ICollection<TimeSlot>? TimeSlots { get; set; }
    }
}
