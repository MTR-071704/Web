﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthScheduler.Domain.Entities
{
    public class TimeSlot
    {
        public int Id { get; set; }

        [DataType(DataType.Date)]
        public DateTime Date { get; set; } // Ngày khám

        public TimeSpan StartTime { get; set; } // Giờ bắt đầu (ví dụ: 08:00)

        public TimeSpan EndTime { get; set; }   // Giờ kết thúc (ví dụ: 08:30)

        public string? Period { get; set; } // Sáng / Chiều / Tối (tuỳ chọn hiển thị)

        // Mỗi TimeSlot thuộc về 1 Service
        public int ServiceId { get; set; }
        public Service? Service { get; set; }

        // Navigation: Lịch hẹn đã đặt tại khung giờ này
        public ICollection<Appointment>? Appointments { get; set; }
    }
}
