﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthScheduler.Domain.Enums
{
    public enum AppointmentStatus
    {
        Pending = 0,      // Người dùng vừa đặt, chờ admin duyệt
        Confirmed = 1,    // Đã được xác nhận (hoặc tự động duyệt)
        Canceled = 2      // Đã bị huỷ (do người dùng hoặc admin)
    }
}
