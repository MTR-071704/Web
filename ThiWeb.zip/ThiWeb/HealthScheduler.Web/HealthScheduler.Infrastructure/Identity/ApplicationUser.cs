﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace HealthScheduler.Domain.Entities
{
    public class ApplicationUser : IdentityUser
    {
        // Thêm các trường bổ sung nếu cần
        public string? FullName { get; set; }

        // Navigation: Các cuộc hẹn của người dùng
        public ICollection<Appointment>? Appointments { get; set; }
    
    }
}
