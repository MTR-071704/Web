﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HealthScheduler.Domain.Entities;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;

namespace HealthScheduler.Infrastructure.Data.Configurations
{
    public class AppointmentConfig : IEntityTypeConfiguration<Appointment>
    {
        public void Configure(EntityTypeBuilder<Appointment> builder)
        {
            builder.HasKey(x => x.Id);

            builder.Property(x => x.FullName)
                   .IsRequired()
                   .HasMaxLength(100);

            builder.Property(x => x.Phone)
                   .IsRequired()
                   .HasMaxLength(20);

            builder.Property(x => x.Gender)
                   .IsRequired()
                   .HasMaxLength(10);

            builder.Property(x => x.Status)
                   .IsRequired();

            builder.HasOne(x => x.TimeSlot)
                   .WithMany(t => t.Appointments)
                   .HasForeignKey(x => x.TimeSlotId)
                   .OnDelete(DeleteBehavior.Cascade);

            builder.Property(x => x.Reason)
                   .HasMaxLength(500);
        }
    }
}
